# my code
# import boto3

# client = boto3.client('sns')

# response = client.create_topic(
#     Name='Discount-offers-shruthib',
#     Attributes={},
#     Tags=[
#         {
#             'Key': 'user',
#             'Value': 'shruthib'
#         },
#     ]
# )

# print(response['TopicArn'])

# response = client.subscribe(
#     TopicArn=response['TopicArn'],
#     Protocol='email',
#     Endpoint='bh.shruthi224@gmail.com'
# )

# print(response['SubscriptionArn'])

# client.publish(
#     TopicArn='arn:aws:sns:ap-northeast-2:106129732153:Discount-offers-shruthib', 
#     Subject="Latest News in Pune", 
#     Message="The qucik brown fox jumps over the lazy dog."
#     )

# or

# import boto3
# import json
# sns = boto3.resource("sns")
# client = boto3.client('sns')
# topic = sns.create_topic(Name='Discount-offers-sejal')
# protocol='Email'
# endpoint='sejalchaudhari0520@gmail.com'
# subscription = topic.subscribe(Protocol=protocol, Endpoint=endpoint, ReturnSubscriptionArn=True)
# message='SNS TOPIC CREATED'
# response = client.publish(TargetArn=subscription,Message=json.dumps(message))

# or

# import boto3
# sns = boto3.resource("sns")
# topic = sns.create_topic(Name='Discount-offers-anjani')
# protocol='Email'
# endpoint='anjanirouthu@gmail.com'
# topic.subscribe(Protocol=protocol,Endpoint=endpoint,ReturnSubscriptionArn=True)
# topic.publish(Message = "Hi This is Anjani",Subject ="Welcome")

# or

# Sirs code

import boto3
 
client = boto3.client('sns')
 
resp1 = client.create_topic(Name="discountoffers1")
arn = resp1['TopicArn']
print ("Created a new topic "+arn)
 
resp2 = client.subscribe(TopicArn=arn, Protocol='email', Endpoint='bh.shruthi2002@gmail.com', ReturnSubscriptionArn=True)
