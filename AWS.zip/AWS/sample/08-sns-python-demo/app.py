import boto3
# import json

client = boto3.client('sns')
 
response = client.list_topics()
 
for topic in response['Topics']:
    arn = topic['TopicArn']
    name = arn.split(':')
    print ("Topic Name: ",name[5])
    response = client.list_subscriptions_by_topic(TopicArn=arn)
    for sub in response['Subscriptions']:
        print("[ {}] {}".format(sub['Protocol'], sub['Endpoint']))

# print("Print a news")

# response1 = client.publish(
#     TargetArn='arn:aws:sns:ap-northeast-2:106129732153:shruthibh224',
#     Message=json.dumps("SNS message")
# )

# print(response1)

# or

client.publish(
    TopicArn='arn:aws:sns:ap-northeast-2:106129732153:shruthibh224', 
    Subject="Latest News in Pune", 
    Message="The qucik brown fox jumps over the lazy dog."
    )





# topic.confirm_subscription(
#     Token='string',
#     AuthenticateOnUnsubscribe='string'
# )
 
# delete_topic
# response = client.delete_topic(
#     TopicArn='string'
# )
 
# unsubscribe
# response = client.unsubscribe(
#     SubscriptionArn='string'
# )