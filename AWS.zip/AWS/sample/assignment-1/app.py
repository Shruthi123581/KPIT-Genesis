import boto3,os

# accessing the buckets on AWS

client = boto3.client('s3')

s3 = boto3.resource('s3')

bucket_name = 'shruthib-reports'
region = 'us-west-2'

client=boto3.client('s3')
client.put_object(Bucket='shruthib-reports',Key='jan.txt',Body=b'January')

client.put_object(Bucket='shruthib-reports',Key='feb.txt',Body=b'February')

client.put_object(Bucket='shruthib-reports',Key='march.txt',Body=b'March')

download_path="C:\\files"

lists = client.list_objects(Bucket=bucket_name)['Contents']
 
for obj in lists:
    file_key = obj['Key']
    local_path = os.path.join(download_path, file_key)
    client.download_file(bucket_name, file_key, local_path)
    print(f"Downloaded {file_key} to {local_path}")