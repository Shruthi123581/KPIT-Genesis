import boto3

# accessing the buckets on AWS

client = boto3.client('s3')

s3 = boto3.resource('s3')

for bucket in s3.buckets.all():
    print(bucket.name)
    

# create bucket using python

# by default
# response = s3.create_bucket(Bucket='abcd364687')
# print (response)

# by specifying location
bucket_name = 'shruthib40'
region = 'ap-northeast-2'  
s3.create_bucket(
    Bucket=bucket_name, 
    CreateBucketConfiguration={'LocationConstraint': region}
    )
print("S3 bucket {} created successfully in region {} ".format(bucket_name,region))

# or

# response = s3.create_bucket(
#     Bucket='xyz1y2yt',
#     CreateBucketConfiguration={
#         'LocationConstraint': 'us-east-1',
#     },
# )
 
# Get the S3 xlient to perform CRUD on bucket objects

# client=boto3.client('s3')
# client.put_object(Bucket='shruthib40',Key='file101.txt',Body=b'Hello World')

# client.delete_bucket(Bucket='zjan5')


# client.put_object(Bucket='shruthib41', Key='file01.txt', Body=b'Hello World')

# delete objects and bucket 

# s3_bucket = s3.Bucket("cm08-vvh-bk")
# bucket_versioning = s3.BucketVersioning("cm08-vvh-bk")
# if bucket_versioning.status == 'Enabled':
#     s3_bucket.object_versions.delete()
 
# else:
#     s3_bucket.objects.all().delete()
#     client.delete_bucket (Bucket="cm08-vvh-bk")


# copy bucket
# import boto3
# s3 = boto3.resource('s3')
# copy_source = {
#     'Bucket': 'zabcd36468',
#     'Key': 'file101.txt'
# }
# s3.meta.client.copy(copy_source, 'f1-reports', 'file10.txt')