-- use sampledb;

select * from employees;