-- create SCHEMA sampledatabase1;

-- use sampledatabase1;

-- CREATE TABLE employees
-- ( empid int primary key auto_increment,
-- firstname nvarchar(20),
-- lastname nvarchar(30));

-- INSERT into employees (firstname, lastname)
-- VALUES ('Donald','Duck');

-- INSERT into employees (firstname, lastname)
-- VALUES ('Shruthi','Bhupathiraju');

select * from employees;



-- create SCHEMA bills;

-- use bills;

-- CREATE TABLE utilitybills (
--     monthName varchar(10),
--     UnitsUsed int,
--     PayableAmount int
-- );

-- INSERT into utilitybills (monthName, UnitsUsed, PayableAmount)
-- VALUES ('Jan',120,870);
-- INSERT into utilitybills (monthName, UnitsUsed, PayableAmount)
-- VALUES ('Feb',87,730);
-- INSERT into utilitybills (monthName, UnitsUsed, PayableAmount)
-- VALUES ('Mar',92,810);
-- INSERT into utilitybills (monthName, UnitsUsed, PayableAmount)
-- VALUES ('Apr',77,920);

-- SELECT * FROM utilitybills;