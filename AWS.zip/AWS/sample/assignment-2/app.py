import boto3
import mysql.connector
 
client = boto3.client('sns')
 
topic_arn = 'arn:aws:sns:ap-northeast-2:106129732153:bill-alerts-shruthib'
 
 
try:
    connection = mysql.connector.connect(
        host = 'dbshruthi.c72ss44wo335.ap-northeast-2.rds.amazonaws.com',
        user = 'admin',
        password = 'Shruthi123',
        database = 'bills'
 
    )
 
    if connection.is_connected():
        cursor = connection.cursor()
 
        # cursor.execute('select count(month) from utility_bills')
        # total_bills = cursor.fetchall()
        # print(total_bills)

        cursor.execute('select * from utilitybills')
 
        rows = cursor.fetchall()
 
        for row in rows:
            # print(row)
            client.publish(TopicArn = topic_arn, Message="Hi,\n You bill for month {} is due. Please pay Rs {} in 15 days.".format(row[0],row[2]))
            print("Mail sent successfully")
 
except mysql.connector.Error as err:
    print("Error found as {}".format(err))
 
finally:
    if 'cursor' in locals():
        cursor.close()
    if 'connection' in locals() and connection.is_connected():
        connection.close()
        print("Connection closed")

'''or---------------------------------------------------

import boto3
import mysql.connector
from datetime import datetime
 
# AWS configuration
sns_topic_arn = "arn:aws:sns:ap-northeast-2:106129732153:bill-alerts-shruthib"
 
# RDS configuration
rds_host = "dbshruthi.c72ss44wo335.ap-northeast-2.rds.amazonaws.com"
rds_user = "admin"
rds_password = "Shruthi123"
rds_db_name = "bills"
 
def send_bill_alert(subscriber, month, amount):
    message = f"Hi,\n\nYour bill for the month {month} is due. Please pay Rs {amount} in 15 days."
 
    # Print message to console (replace this with actual email sending code)
    print(f"Sending bill alert to {subscriber}: {message}")
 
def fetch_bills_data():
    connection = None  # Initialize the connection variable
 
    try:
        # Connect to RDS MySQL
        connection = mysql.connector.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            database=rds_db_name
        )
 
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM utilitybills")
            result = cursor.fetchall()
            return result
 
    except Exception as e:
        print(f"Error connecting to RDS: {e}")
 
    finally:
        if connection and connection.is_connected():
            connection.close()
 
def get_subscribers_from_sns(topic_arn):
    sns_client = boto3.client('sns')
    response = sns_client.list_subscriptions_by_topic(TopicArn=topic_arn)
    subscribers = [subscription['Endpoint'] for subscription in response['Subscriptions']]
    return subscribers
 
def main():
    # Fetch subscribers from SNS topic
    sns_client = boto3.client('sns')
    subscribers = get_subscribers_from_sns(sns_topic_arn)
 
    # Fetch bills data from RDS
    bills_data = fetch_bills_data()
 
    if not bills_data:
        print("No data fetched from RDS. Exiting.")
        return
 
    # Iterate through bills data and send alerts
    for bill in bills_data:
        month = bill["monthName"]
        amount = bill["PayableAmount"]
 
        # Publish to SNS topic
        sns_client.publish(
            TopicArn=sns_topic_arn,
            Subject=f"Bill Alert: Payment Due for {month}",
            Message=f"Hi,\n\nYour bill for the month {month} is due. Please pay Rs {amount} in 15 days."
        )
 
        # Send emails to subscribers
        for subscriber in subscribers:
            send_bill_alert(subscriber, month, amount)
 
if __name__ == "__main__":
    main()

'''
