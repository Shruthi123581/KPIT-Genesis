import boto3
import mysql.connector
import time

# Define a function to fetch data from RDS MySQL
def fetch_data_from_rds():
    # Replace the following with your RDS MySQL credentials
    rds_host = 'your-rds-host'
    rds_user = 'your-rds-user'
    rds_password = 'your-rds-password'
    rds_database = 'your-rds-database'

    # Connect to RDS MySQL
    connection = mysql.connector.connect(
        host=rds_host,
        user=rds_user,
        password=rds_password,
        database=rds_database
    )

    # Fetch data from RDS MySQL
    cursor = connection.cursor(dictionary=True) 
    cursor.execute("SELECT * FROM your_table")
    data = cursor.fetchall()

    # Close the connection
    cursor.close()
    connection.close()

    return data

# Define a function to send a message to SQS
def send_message_to_sqs(message):
    # Replace the following with your SQS queue URL
    sqs_queue_url = 'your-sqs-queue-url'

    # Create an SQS client
    sqs = boto3.client('sqs')

    # Send a message to SQS
    response = sqs.send_message(
        QueueUrl=sqs_queue_url,
        MessageBody=message
    )

    print(f"Message sent to SQS: {message}")

# Fetch data from RDS MySQL
data = fetch_data_from_rds()

# Send each row as a message to SQS
for row in data:
    message = f"Row fetched from RDS MySQL: {row}"
    send_message_to_sqs(message)

# Wait for 5 seconds before exiting
time.sleep(5)