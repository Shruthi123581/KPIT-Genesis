import boto3

queueUrl = "https://sqs.ap-northeast-2.amazonaws.com/106129732153/orders"
sqs = boto3.client('sqs')

# or

# sqs = boto3.client('sqs', region_name='ap-northeast-2')

sqs.send_message(
    QueueUrl=queueUrl,
    MessageBody=('Hello Shruthi')
)

response = sqs.receive_message(QueueUrl=queueUrl)

for message in response['Messages']:
    print(message['Body'])

# response = sqs.create_queue(
#     QueueName='shruthicreate',
#     Attributes={},
#     tags={
#         'user': 'string'
#     }
# )





# create_queue
# response = sqs.create_queue(
#     QueueName='shruthicreate',
#     Attributes={},
#     tags={
#         'user': 'string'
#     }
# )
   
 
 
# delete_message
# response = client.delete_message(
#     QueueUrl='string',
#     ReceiptHandle='string'
# )
   
 
   
# delete_queue
# response = client.delete_queue(
#     QueueUrl='string'
# )
   
 