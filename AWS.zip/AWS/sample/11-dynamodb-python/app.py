import boto3

# # Replace these values with your own
# aws_access_key_id = 'YOUR_ACCESS_KEY'
# aws_secret_access_key = 'YOUR_SECRET_KEY'
# region_name = 'YOUR_REGION'
# table_name = 'YourTableName'

# # Initialize DynamoDB client
# dynamodb = boto3.client(
#     'dynamodb',
#     aws_access_key_id=aws_access_key_id,
#     aws_secret_access_key=aws_secret_access_key,
#     region_name=region_name
# )

# or-------------------------------------

# Replace these values with your own
# aws_access_key_id = 'YOUR_ACCESS_KEY'
# aws_secret_access_key = 'YOUR_SECRET_KEY'
# region_name = 'YOUR_REGION'
table_name = 'shruthibh'

# Initialize DynamoDB client
dynamodb = boto3.client('dynamodb')

# Define the table schema
table_schema = [
    {
        'AttributeName': 'PrimaryKey',
        'KeyType': 'HASH'  # Hash key
    },
    {
        'AttributeName': 'SortKey',
        'KeyType': 'RANGE'  # Sort key
    }
]

# Define the provisioned throughput for the table
provisioned_throughput = {
    'ReadCapacityUnits': 5,
    'WriteCapacityUnits': 5
}

# Create the table
dynamodb.create_table(
    TableName=table_name,
    AttributeDefinitions=[
        {'AttributeName': 'PrimaryKey', 'AttributeType': 'S'},
        {'AttributeName': 'SortKey', 'AttributeType': 'N'}
    ],
    KeySchema=table_schema,
    ProvisionedThroughput=provisioned_throughput
)

print(f'Table {table_name} created. Please wait for it to become active.')

# Wait for the table to become active
dynamodb.get_waiter('table_exists').wait(
    TableName=table_name
)

# Put some sample records into the table
items_to_put = [
    {'PrimaryKey': {'S': 'item1'}, 'SortKey': {'N': '123'}, 'Attribute1': {'S': 'Value1'}},
    {'PrimaryKey': {'S': 'item2'}, 'SortKey': {'N': '456'}, 'Attribute1': {'S': 'Value2'}},
    # Add more items as needed
]

for item in items_to_put:
    dynamodb.put_item(
        TableName=table_name,
        Item=item
    )

    

print('Records added to the table.')