import mysql.connector

# AWS RDS MySQL connection parameters
host = "sampledatabase-1.c72ss44wo335.ap-northeast-2.rds.amazonaws.com"
user="admin"
password = "Password!1234"
database = "sampledatabase1"

# Establish a connection
try:
    connection = mysql.connector.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )
    if connection.is_connected():
        print("Connected to the database")
        
        # Create a cursor
        cursor = connection.cursor()

        # Execute SQL queries
        cursor.execute("SELECT * FROM employees")
        rows = cursor.fetchall()
        # rows = cursor.fetchall()[1:]

        # Process the result
        for row in rows:
            print(row)

except mysql.connector.Error as err:
    print(f"Error: {err}")

finally:
    # Close the cursor and connection
    if 'cursor' in locals():
        cursor.close()
    if 'connection' in locals() and connection.is_connected():
        connection.close()
        print("Connection closed")