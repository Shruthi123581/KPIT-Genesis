import boto3
 
dynamodb=boto3.client('dynamodb')
 
table_name="shruthidb1"
item=dynamodb.get_item(TableName=table_name,Key={'productId':{'S':'P10102'}, 'category':{'S':'Storage Device'}})
# s=[]
# s=item.keys()
if 'Item' in item:
    print("Item found",item['Item'])
else:
    print("Item not found")