# import boto3
import mysql.connector

def insert_data(conn):
    cursor = conn.cursor()

    rides = [
        (4, 'driver4', 'customer4', 4),
        (5, 'driver5', 'customer5', 5),
        (6, 'driver6', 'customer6', 6)
    ]

    for ride in rides:
        cursor.execute("INSERT INTO kuberride (rideno, driver, customer, passcount) VALUES (%s, %s, %s, %s)",ride)

    conn.commit()
    print("Data inserted successfully")

def main():
    conn = None
    try:
        conn = mysql.connector.connect(
        host = 'dbshruthi.c72ss44wo335.ap-northeast-2.rds.amazonaws.com',
        user = 'admin',
        password = 'Shruthi123',
        database = 'ridedetails'
 
    )
        print("Connected to the database")
    except Exception as e:
        print("Error while connecting to database")
    if conn is not None:
        insert_data(conn)
        conn.close()
    return conn

if __name__ == "__main__":
    main()