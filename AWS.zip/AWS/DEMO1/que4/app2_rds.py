# import boto3
import mysql.connector

def insert_data(conn):
    cursor = conn.cursor()

    drivername = input("Enter driver name: ")
    customername = input("Enter customer name: ")
    no_passengers = input("Enter no of passengers: ")

    rides = [
        (drivername,customername, no_passengers)
    ]

    for ride in rides:
        cursor.execute("INSERT INTO kuberride2 (drivername, customername, no_passengers) VALUES (%s, %s, %s)",ride)

    conn.commit()
    print("Data inserted successfully")

def main():
    conn = None
    try:
        conn = mysql.connector.connect(
        host = 'dbshruthi.c72ss44wo335.ap-northeast-2.rds.amazonaws.com',
        user = 'admin',
        password = 'Shruthi123',
        database = 'ridedetails'
 
    )
        print("Connected to the database")
    except Exception as e:
        print("Error while connecting to database")
    if conn is not None:
        insert_data(conn)
        conn.close()
    return conn

if __name__ == "__main__":
    main()