-- create SCHEMA ridedetails;

use ridedetails;

-- use ridedetails;

-- CREATE TABLE kuberride (
--     rideno INT,
--     driver varchar(20),
--     customer varchar(20),
--     passcount INT
-- );

-- SELECT * FROM kuberride;
