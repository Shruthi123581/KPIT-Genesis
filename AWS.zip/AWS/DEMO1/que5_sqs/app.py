import boto3

sqs = boto3.client('sqs')
queue_url = 'https://sqs.ap-northeast-2.amazonaws.com/106129732153/ride-requests-shruthi'

source = input("Enter the source: ")
destination = input("Enter the destination: ")
rides = [(source, destination)]

for ride in rides:
    response = sqs.send_message(QueueUrl=queue_url,MessageBody=(f'Book a ride from {source} and {destination}'))
    print("Message sent successfully")