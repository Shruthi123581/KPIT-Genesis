-- create SCHEMA ridedetails12;

-- use ridedetails12;

-- CREATE TABLE kuberride2 (
--     rideno INT primary key auto_increment,
--     driver varchar(20),
--     customer varchar(20),
--     passcount INT
-- );